package com.uma.linkdlen;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

import com.uma.linkdlen.service.EmailService;

import jakarta.mail.MessagingException;

@SpringBootApplication
public class SendingMailApplication {
	@Autowired
	private EmailService service;
	

	public static void main(String[] args) {
		SpringApplication.run(SendingMailApplication.class, args);
	}
	@EventListener(ApplicationReadyEvent.class)
	public void triggerEmail() throws MessagingException{
		service.sendEmail("twinsveerapaneni@gmail.com","this is body " ,"resume","/home/hariveerapaneni/Desktop/Resume.pdf" );
	}

}
