package com.uma.linkdlen.service;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {
	
	    @Autowired
	    private JavaMailSender javaMailSender;

	    public void sendEmail(String toEmail,String body,String subject, String attachment) throws MessagingException {
	      MimeMessage mineMessage=javaMailSender.createMimeMessage();
	      MimeMessageHelper mimeMessageHelper=new MimeMessageHelper(mineMessage,true);
	      mimeMessageHelper.setFrom("umaveerapaneni@gmail.com");
	      mimeMessageHelper.setTo(toEmail);
	      mimeMessageHelper.setSubject(subject);
	      mimeMessageHelper.setText(body);

	      FileSystemResource fileSystemResource=new FileSystemResource(new File(attachment));
	      mimeMessageHelper.addAttachment(fileSystemResource.getFilename(),fileSystemResource);
	      javaMailSender.send(mineMessage);
	      System.out.println("mail sent");
	    }
	}

