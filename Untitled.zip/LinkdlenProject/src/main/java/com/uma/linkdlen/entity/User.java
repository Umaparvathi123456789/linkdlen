package com.uma.linkdlen.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private String  jobTitles;
	@Column
	private String LocationTypes;
	@Column
	private String LocationOnSite;
	@Column
	private String startDate;
	@Column
	private String employementType;
	@Column
	private String visibility;

	public String getjobTitles() {
		return jobTitles;
	}
	public void setJobtitles(String jobtitles) {
		jobTitles = jobtitles;
	}
	public String getLocationTypes() {
		return LocationTypes;
	}
	public void setLocationTypes(String locationTypes) {
		LocationTypes = locationTypes;
	}
	public String getLocationOnSite() {
		return LocationOnSite;
	}
	public void setLocationOnSite(String locationOnSite) {
		LocationOnSite = locationOnSite;
	}
	public String getStartdate() {
		return startDate;
	}
	public void setStartdate(String startdate) {
		this.startDate = startdate;
	}
	public String getEmployementType() {
		return employementType;
	}
	public void setEmployementType(String employementType) {
		this.employementType = employementType;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setVisibility(String visibility) {
	this.visibility = visibility;
	}
	public User get() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
