package com.uma.linkdlen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Linkdlen1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
